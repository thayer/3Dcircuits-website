%Part of circuit animation toolbox; call to initialize some stuff before building circut.
% Version 1.2, May 2002.


% This code is for pseudo-compatibility with v1.1
%global CANI_XES CANI_YS;
%if length(CANI_XES)<2,
%    makegrid(3,3)
%end

figure(1)
clf
reset(gcf)
ca = cell(0);
ia = cell(0);


