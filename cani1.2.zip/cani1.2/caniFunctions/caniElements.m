%Circuit Elements Available in the Circuit Animation Toolbox
%
%Standard elements, added by the syntax
%ca = addX(ca,n1,n2)
%where X is:
%L, R, C, wire, V, I
%and n1 and n2 are the nodes it is connected between.
%
%Special elements, with different syntax.  See the help on each for details.
%addD, addswitch, addopamp.   (Diode, switch and opamp)

%This is only a help file.